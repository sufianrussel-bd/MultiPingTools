@echo off
setlocal EnableDelayedExpansion
title Multi Ping Tools - Update
color 0B

REM ==========================================================
REM   MULTI PING TOOLS  -  ONE CLICK UPDATE
REM   Smart Technologies (BD) Ltd.  |  Open Source
REM
REM   Copies a newer build from the folder listed in
REM   update_source.txt (a network share, mapped drive or USB).
REM
REM   OFFLINE ONLY. This does not use the internet and does not
REM   contact any vendor server. It is a plain file copy from a
REM   location that YOU control.
REM ==========================================================

cd /d "%~dp0"

set "AUTO="
if /i "%~1"=="/auto" set "AUTO=1"

cls
echo.
echo   ============================================================
echo      MULTI PING TOOLS   -   UPDATE
echo   ============================================================
echo.

REM ---------- local version ---------------------------------
set "LOCALVER=unknown"
if exist "version.txt" (
    for /f "usebackq tokens=* delims=" %%v in ("version.txt") do (
        if not defined VTMP set "VTMP=%%v"
    )
    if defined VTMP set "LOCALVER=!VTMP!"
)
echo   Installed version :  !LOCALVER!

REM ---------- read the configured source --------------------
if not exist "update_source.txt" goto NOCONFIG

set "SRC="
for /f "usebackq tokens=* delims=" %%p in ("update_source.txt") do (
    set "LINE=%%p"
    if not defined SRC (
        if not "!LINE!"=="" (
            set "FIRSTCH=!LINE:~0,1!"
            if not "!FIRSTCH!"=="#" set "SRC=!LINE!"
        )
    )
)
if not defined SRC goto NOCONFIG

REM strip surrounding quotes and trailing backslash
set "SRC=!SRC:"=!"
if "!SRC:~-1!"=="\" set "SRC=!SRC:~0,-1!"

echo   Update source     :  !SRC!
echo.

if not exist "!SRC!\" goto UNREACHABLE

REM ---------- remote version --------------------------------
set "REMOTEVER=unknown"
if exist "!SRC!\version.txt" (
    for /f "usebackq tokens=* delims=" %%v in ("!SRC!\version.txt") do (
        if not defined RTMP set "RTMP=%%v"
    )
    if defined RTMP set "REMOTEVER=!RTMP!"
)
echo   Available version :  !REMOTEVER!
echo.

if "!REMOTEVER!"=="unknown" goto NOREMOTEVER
if "!REMOTEVER!"=="!LOCALVER!" goto ALREADYCURRENT

if not exist "!SRC!\MultiPingTools.exe" goto BADSOURCE

REM ---------- confirm ---------------------------------------
if not defined AUTO (
    echo   ------------------------------------------------------------
    echo     This will replace the files in:
    echo        %CD%
    echo     with the build from:
    echo        !SRC!
    echo.
    echo     Your current folder is backed up first.
    echo   ------------------------------------------------------------
    echo.
    choice /c YN /n /m "   Install version !REMOTEVER! now?  [Y/N] "
    if errorlevel 2 goto CANCELLED
    echo.
)

REM ---------- wait for the app to close ---------------------
echo   [1/4]  Waiting for the application to close ...
set /a WAITED=0
:WAITLOOP
tasklist /fi "imagename eq MultiPingTools.exe" 2>nul | find /i "MultiPingTools.exe" >nul
if errorlevel 1 goto CLOSED
set /a WAITED+=1
if !WAITED! GEQ 20 goto STILLRUNNING
timeout /t 1 >nul
goto WAITLOOP

:STILLRUNNING
echo          Still running. Please close Multi Ping Tools, then
echo          press any key to continue.
pause >nul
goto WAITLOOP

:CLOSED
echo          Closed.

REM ---------- backup ----------------------------------------
for /f "tokens=2 delims==" %%t in ('wmic os get localdatetime /value 2^>nul') do set "DT=%%t"
if not defined DT set "DT=backup"
set "STAMP=!DT:~0,8!_!DT:~8,6!"
set "BAK=%CD%\_backup_!LOCALVER!_!STAMP!"

echo   [2/4]  Backing up current version ...
md "!BAK!" 2>nul
for %%F in (*.exe *.dll *.pyd *.txt *.csv *.bat) do (
    copy /y "%%F" "!BAK!\" >nul 2>&1
)
if exist "_internal" (
    robocopy "_internal" "!BAK!\_internal" /e /njh /njs /ndl /nc /ns /nfl >nul 2>&1
)
echo          Saved to: !BAK!

REM ---------- copy the new build ----------------------------
echo   [3/4]  Copying version !REMOTEVER! ...
robocopy "!SRC!" "%CD%" /e /njh /njs /ndl /nc /ns /nfl /xf update_source.txt /xd "_backup_*" >nul
if errorlevel 8 goto COPYFAIL
echo          Done.

REM ---------- relaunch --------------------------------------
echo   [4/4]  Starting the new version ...
cls
color 0A
echo.
echo   ============================================================
echo      UPDATE COMPLETE
echo   ============================================================
echo.
echo      Updated  :  !LOCALVER!   ->   !REMOTEVER!
echo      Backup   :  !BAK!
echo.
echo      If anything goes wrong, copy the files from the backup
echo      folder back here. Delete old _backup_* folders when you
echo      are happy with the new version.
echo.
timeout /t 2 >nul
start "" "%CD%\MultiPingTools.exe"
exit /b 0


:NOCONFIG
color 0E
echo.
echo   ------------------------------------------------------------
echo     UPDATE SOURCE NOT CONFIGURED
echo   ------------------------------------------------------------
echo.
echo     Create or edit this file:
echo.
echo        %CD%\update_source.txt
echo.
echo     Put ONE line in it - the folder where your team publishes
echo     new builds. Examples:
echo.
echo        \\fileserver\tools\MultiPingTools
echo        D:\Tools\MultiPingTools
echo        E:\MultiPingTools            (USB stick)
echo.
echo     Then run this updater again.
echo.
echo     Opening the file for you now...
timeout /t 2 >nul
if not exist "update_source.txt" (
    echo # Put the update folder path on the line below.>update_source.txt
    echo # Example: \\fileserver\tools\MultiPingTools>>update_source.txt
)
start "" notepad "%CD%\update_source.txt"
pause
exit /b 1

:UNREACHABLE
color 0E
echo.
echo   *** UPDATE FOLDER NOT REACHABLE ***
echo.
echo     !SRC!
echo.
echo   Check that you are on the office network or VPN, and that
echo   the drive is mapped. Then try again.
echo.
pause
exit /b 1

:NOREMOTEVER
color 0E
echo.
echo   *** NO version.txt IN THE UPDATE FOLDER ***
echo.
echo   Cannot tell which version is published there, so nothing
echo   was changed. Ask whoever maintains the share to publish
echo   with PUBLISH.bat.
echo.
pause
exit /b 1

:BADSOURCE
color 0E
echo.
echo   *** UPDATE FOLDER HAS NO MultiPingTools.exe ***
echo.
echo     !SRC!
echo.
echo   Nothing was changed.
echo.
pause
exit /b 1

:ALREADYCURRENT
color 0A
echo.
echo   You are already running the latest version (!LOCALVER!).
echo   Nothing to do.
echo.
if defined AUTO ( timeout /t 3 >nul ) else ( pause )
exit /b 0

:CANCELLED
echo.
echo   Cancelled. Nothing was changed.
echo.
pause
exit /b 0

:COPYFAIL
color 0C
echo.
echo   *** COPY FAILED ***
echo.
echo   The update could not be copied. Your previous version is
echo   still in place, and a backup is at:
echo      !BAK!
echo.
pause
exit /b 1
